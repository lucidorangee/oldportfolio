
public class Path
{
	private Node node; //Connected Node
	private int weight;	//Weight of the path
	
	public Path(Node n, int w)
	{
		node = n;
		weight = w;
	}
	
	/**
	 * Returns the node it is connected to
	 * @return Node
	 */
	public Node getNode()
	{
		return node;
	}
	
	/**
	 * Returns the weight of the path
	 * @return int
	 */
	public int getWeight()
	{
		return weight;
	}
}
