
public class Runner
{
	public static void main(String[] args)
	{
		Node node_A = new Node();
		Node node_B = new Node();
		Node node_C = new Node();
		Node node_D = new Node();
		
		Node.connectNodes(node_A, node_B, 1);
		Node.connectNodes(node_A, node_C, 1);
		Node.connectNodes(node_B, node_D, 4);
		Node.connectNodes(node_C, node_D, 3);
		
		Dijkstra.dijkstra(node_A, node_D);
	}
}
