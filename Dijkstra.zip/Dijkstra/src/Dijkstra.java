import java.util.PriorityQueue;

public class Dijkstra
{
	public static void dijkstra(Node start, Node end)
	{
		//PriorityQueue to store nodes from smallest weight to the largest
		PriorityQueue<Node> pq = new PriorityQueue<Node>(10, new CompareNode());
		pq.add(start); //Add starting node to the queue
		start.setWeight(0); //Starting node's weight is 0 (since distance from starting node to itself is 0)
		
		//While there are nodes to process
		while(pq.size() > 0)
		{
			Node n1 = pq.poll();
			//If the node is not open, there's a shorter route to here anyway.
			//	As well, if it's the ending node, no need to worry anything
			if(!n1.isOpen() || n1 == end) continue; 
			
			//For every path
			for(int i = 0; i < n1.getPaths().size(); i++)
			{
				//Get the current path and the node the path connects to
				Path p = n1.getPaths().get(i);
				Node n2 = p.getNode();
				
				//If the to-node is open and the accumulated weight of the 
				//	from-node and path is noteworthy, add the n2 to the queue
				if(n2.isOpen() && n2.getWeight() > n1.getWeight() + p.getWeight())
				{
					//Set the weight of the to-node, as well as reset its parent to from-node,
					//	then add the to-node to the queue.
					n2.setWeight(n1.getWeight() + p.getWeight());
					n2.setParent(n1);
					pq.add(n2);
				}
				
			}
			
			n1.close();
		}
		
		System.out.println(end.getWeight());
		
		String str = "";
		Node n = end;
		while(n.getParent() != null)
		{
			str += n.getWeight() + " ";
			n = n.getParent();
		}
		
		str += n.getWeight();
		
		for(int i = str.length() - 1; i >= 0; i--)
		{
			System.out.print(str.charAt(i));
		}
		
	}

	

}

