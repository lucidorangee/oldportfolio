import java.util.ArrayList;

public class Node
{
	private ArrayList<Path> paths; //In this case, Point is used for (int, int) not (x, y)
	private int weight;
	private Node parent;
	private boolean open;
	private String name;
	
	/**
	 * Default Constructor
	 */
	public Node()
	{
		name = "";
		setDefault();
	}
	
	/**
	 * Default constructor with name
	 * @param n
	 */
	public Node(String n)
	{
		name = n;
		setDefault();
	}
	
	/**
	 * Initializes its private variables. It is to be used in constructors
	 *  to avoid double coding.
	 */
	private void setDefault()
	{
		paths = new ArrayList<Path>();
		weight = Integer.MAX_VALUE;
		parent = null;
		open = true;
	}
	
	/**
	 * Adds a path that connects to the given node n with the given weight w.
	 * 
	 * @param n
	 * @param w
	 */
	public void addPath(Node n, int w)
	{
		paths.add(new Path(n, w));
	}
	
	/**
	 * Returns an arraylist of available paths from the node
	 * @return
	 */
	public ArrayList<Path> getPaths()
	{
		return paths;
	}
	
	/**
	 * Sets the accumulated weight to the node
	 * @param w
	 */
	public void setWeight(int w)
	{
		weight = w;
	}
	
	/**
	 * Returns the accumulated weight thus far
	 * @return int
	 */
	public int getWeight()
	{
		return weight;
	}
	
	/**
	 * Sets the parent node of the node to the given node
	 * @param n
	 */
	public void setParent(Node n)
	{
		parent = n;
	}
	
	/**
	 * Returns the parent node of this noe
	 * @return Node
	 */
	public Node getParent()
	{
		return parent;
	}
	
	/**
	 * Closes the node/Sets the boolean variable 'open' to false
	 */
	public void close()
	{
		open = false;
	}
	
	/**
	 * Checks and returns a boolean representing the private boolean variable 'open'
	 * @return boolean
	 */
	public boolean isOpen()
	{
		return open;
	}
	
	/**
	 * Returns the name of the node
	 * @return String
	 */
	public String getName()
	{
		return name;
	}
	
	/**
	 * Connects the given two nodes together with a path
	 * @param a
	 * @param b
	 */
	public static void connectNodes(Node a, Node b, int weight)
	{
		a.addPath(b, weight);
		b.addPath(a, weight);
	}
	
}
